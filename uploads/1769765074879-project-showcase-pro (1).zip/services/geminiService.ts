
import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const analyzeProject = async (projectName: string, description: string, techStack: string[]) => {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `You are a senior technical architect. Analyze this software project and provide a professional, one-paragraph executive summary. Focus on the value proposition and the technical complexity of using ${techStack.join(", ")}.
      
      Project Name: ${projectName}
      Description: ${description}`,
      config: {
        temperature: 0.7,
        topP: 0.95,
      },
    });

    return response.text;
  } catch (error) {
    console.error("Gemini Analysis Error:", error);
    return null;
  }
};
