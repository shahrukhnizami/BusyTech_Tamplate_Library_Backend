
import React, { useState, useEffect } from 'react';
import { Project } from './types';
import ProjectCard from './components/ProjectCard';
import UploadForm from './components/UploadForm';
import ProjectDetails from './components/ProjectDetails';
import Button from './components/Button';
import { analyzeProject } from './services/geminiService';

const App: React.FC = () => {
  const [projects, setProjects] = useState<Project[]>([]);
  const [view, setView] = useState<'dashboard' | 'upload' | 'details'>('dashboard');
  const [selectedProjectId, setSelectedProjectId] = useState<string | null>(null);
  const [isInitializing, setIsInitializing] = useState(true);

  // Persistence logic (Simulation of what would be stored in MongoDB via Express)
  useEffect(() => {
    const saved = localStorage.getItem('ps_pro_db_v2');
    if (saved) {
      try {
        setProjects(JSON.parse(saved));
      } catch (e) {
        console.error("Hydration failed", e);
      }
    }
    setIsInitializing(false);
  }, []);

  useEffect(() => {
    if (!isInitializing) {
      localStorage.setItem('ps_pro_db_v2', JSON.stringify(projects));
    }
  }, [projects, isInitializing]);

  const handleSaveProject = async (projectData: Omit<Project, 'id' | 'createdAt'>) => {
    // This is where you would normally call your Express API:
    // await fetch('/api/projects', { method: 'POST', body: JSON.stringify(projectData) });
    
    // AI Enhancement Step
    const aiAnalysis = await analyzeProject(projectData.name, projectData.description, projectData.techStack);

    const newProject: Project = {
      ...projectData,
      id: Math.random().toString(36).substr(2, 9),
      createdAt: Date.now(),
      aiAnalysis: aiAnalysis || "A robust build utilizing modern architectural patterns."
    };

    setProjects(prev => [newProject, ...prev]);
    setView('dashboard');
  };

  const handleDeleteProject = (id: string) => {
    if (confirm("Permanently delete this project from your showcase?")) {
      setProjects(prev => prev.filter(p => p.id !== id));
    }
  };

  const selectedProject = projects.find(p => p.id === selectedProjectId);

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col font-['Inter',_sans-serif]">
      <nav className="sticky top-0 z-50 bg-white/70 backdrop-blur-2xl border-b border-slate-200 px-8 py-5">
        <div className="max-w-7xl mx-auto flex justify-between items-center">
          <div className="flex items-center gap-3 cursor-pointer group" onClick={() => setView('dashboard')}>
            <div className="w-12 h-12 bg-indigo-600 rounded-2xl flex items-center justify-center text-white shadow-xl shadow-indigo-200 group-hover:scale-110 transition-transform">
              <i className="fas fa-rocket text-xl"></i>
            </div>
            <div>
              <span className="block text-xl font-black text-slate-900 tracking-tighter leading-none">PROJECT</span>
              <span className="text-xs font-bold text-indigo-600 tracking-widest uppercase opacity-70">Showcase Pro</span>
            </div>
          </div>
          
          <div className="flex items-center gap-6">
            {view === 'dashboard' && (
              <Button variant="primary" onClick={() => setView('upload')} className="rounded-2xl px-6 py-3">
                <i className="fas fa-plus mr-1"></i> New Project
              </Button>
            )}
            <div className="flex items-center gap-3 pl-6 border-l border-slate-200">
              <div className="text-right hidden sm:block">
                <p className="text-xs font-black text-slate-800 leading-none">John Doe</p>
                <p className="text-[10px] font-bold text-slate-400 uppercase tracking-tighter">Senior Architect</p>
              </div>
              <div className="w-10 h-10 rounded-full bg-slate-200 border-2 border-white shadow-sm overflow-hidden">
                <img src="https://api.dicebear.com/7.x/avataaars/svg?seed=Felix" alt="avatar" />
              </div>
            </div>
          </div>
        </div>
      </nav>

      <main className="flex-1 p-8 md:p-12">
        <div className="max-w-7xl mx-auto">
          {view === 'dashboard' && (
            <div className="space-y-12">
              <div className="flex flex-col md:flex-row justify-between items-end gap-6">
                <div className="space-y-2">
                  <h2 className="text-5xl font-black text-slate-900 tracking-tight">Portfolio Repository</h2>
                  <p className="text-slate-500 font-medium text-lg">You currently have {projects.length} documented deployments.</p>
                </div>
                <div className="flex gap-2 bg-white p-2 rounded-2xl shadow-sm border border-slate-200">
                  <button className="px-5 py-2 bg-slate-900 rounded-xl text-xs font-black text-white uppercase tracking-widest">All Work</button>
                  <button className="px-5 py-2 text-xs font-black text-slate-400 uppercase tracking-widest hover:text-slate-600 transition-colors">Archived</button>
                </div>
              </div>

              {projects.length === 0 ? (
                <div className="bg-white rounded-[3rem] border border-dashed border-slate-300 p-24 text-center flex flex-col items-center gap-6">
                  <div className="w-24 h-24 bg-slate-50 rounded-[2rem] flex items-center justify-center text-slate-200 text-5xl mb-2">
                    <i className="fas fa-folder-open"></i>
                  </div>
                  <h3 className="text-2xl font-black text-slate-800">Your shelf is empty</h3>
                  <p className="text-slate-400 max-w-sm mx-auto font-medium">Capture your architectural decisions, visual progress, and source code in a single, professional profile.</p>
                  <Button variant="primary" onClick={() => setView('upload')} className="mt-4 rounded-2xl px-8 py-4">
                    Document First Project
                  </Button>
                </div>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
                  {projects.map(project => (
                    <ProjectCard 
                      key={project.id} 
                      project={project} 
                      onView={(id) => {
                        setSelectedProjectId(id);
                        setView('details');
                      }}
                      onDelete={handleDeleteProject}
                    />
                  ))}
                </div>
              )}
            </div>
          )}

          {view === 'upload' && (
            <UploadForm 
              onSave={handleSaveProject} 
              onCancel={() => setView('dashboard')} 
            />
          )}

          {view === 'details' && selectedProject && (
            <ProjectDetails 
              project={selectedProject} 
              onBack={() => setView('dashboard')} 
            />
          )}
        </div>
      </main>

      <footer className="bg-white border-t border-slate-200 py-12 px-8">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-center gap-8">
          <div className="flex items-center gap-3 grayscale opacity-50">
             <i className="fas fa-rocket text-xl text-slate-900"></i>
             <span className="font-black text-slate-900 tracking-tighter">PROJECTSHOWCASE</span>
          </div>
          <div className="flex gap-10 text-slate-400 text-xs font-black uppercase tracking-widest">
            <a href="#" className="hover:text-indigo-600 transition-colors">API Endpoint</a>
            <a href="#" className="hover:text-indigo-600 transition-colors">Cloud Storage</a>
            <a href="#" className="hover:text-indigo-600 transition-colors">Support Hub</a>
          </div>
          <p className="text-slate-300 text-[10px] font-bold uppercase tracking-widest">Build 2.0.4-STABLE</p>
        </div>
      </footer>
    </div>
  );
};

export default App;
