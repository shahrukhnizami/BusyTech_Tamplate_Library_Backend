
import React, { useState } from 'react';
import { Project, ProjectSection, ProjectFile } from '../types';
import Button from './Button';

interface UploadFormProps {
  onSave: (project: Omit<Project, 'id' | 'createdAt'>) => void;
  onCancel: () => void;
}

const UploadForm: React.FC<UploadFormProps> = ({ onSave, onCancel }) => {
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [techStack, setTechStack] = useState('');
  const [coverImage, setCoverImage] = useState<string>('');
  
  const [sections, setSections] = useState<ProjectSection[]>([]);
  const [files, setFiles] = useState<ProjectFile[]>([]);
  const [zipFile, setZipFile] = useState<ProjectFile | null>(null);

  const [isSubmitting, setIsSubmitting] = useState(false);

  const readFileAsBase64 = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result as string);
      reader.onerror = reject;
      reader.readAsDataURL(file);
    });
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>, isZip: boolean = false) => {
    const uploadedFiles = e.target.files;
    if (!uploadedFiles) return;

    for (const file of Array.from(uploadedFiles)) {
      const base64 = await readFileAsBase64(file);
      const newFile: ProjectFile = {
        id: Math.random().toString(36).substr(2, 9),
        name: file.name,
        data: base64,
        type: file.type,
        size: file.size
      };

      if (isZip) {
        setZipFile(newFile);
      } else {
        setFiles(prev => [...prev, newFile]);
      }
    }
    // Reset input
    e.target.value = '';
  };

  const handleCoverUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const base64 = await readFileAsBase64(file);
      setCoverImage(base64);
    }
  };

  const addSection = () => {
    setSections(prev => [
      ...prev,
      { id: Math.random().toString(36).substr(2, 9), title: '', description: '', screenshot: '' }
    ]);
  };

  const updateSection = (id: string, updates: Partial<ProjectSection>) => {
    setSections(prev => prev.map(s => s.id === id ? { ...s, ...updates } : s));
  };

  const removeSection = (id: string) => {
    setSections(prev => prev.filter(s => s.id !== id));
  };

  const handleSectionImage = async (e: React.ChangeEvent<HTMLInputElement>, id: string) => {
    const file = e.target.files?.[0];
    if (file) {
      const base64 = await readFileAsBase64(file);
      updateSection(id, { screenshot: base64 });
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    const projectData = {
      name,
      description,
      techStack: techStack.split(',').map(s => s.trim()).filter(s => s !== ""),
      coverImage,
      sections,
      files,
      zipFile
    };

    onSave(projectData);
  };

  return (
    <form onSubmit={handleSubmit} className="max-w-4xl mx-auto space-y-10 pb-20 animate-in slide-in-from-bottom-4 duration-500">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-3xl font-black text-slate-900">Project Workspace</h2>
          <p className="text-slate-500">Document your build, attach source code, and share visuals.</p>
        </div>
        <Button variant="ghost" type="button" onClick={onCancel}>
          <i className="fas fa-times"></i> Discard
        </Button>
      </div>

      <div className="bg-white rounded-3xl p-8 shadow-xl shadow-slate-200/50 border border-slate-100 space-y-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="space-y-3">
            <label className="text-sm font-bold text-slate-700 uppercase tracking-wider">Project Cover</label>
            <div className="relative aspect-video rounded-2xl border-2 border-dashed border-slate-200 bg-slate-50 flex flex-col items-center justify-center overflow-hidden hover:border-indigo-400 transition-all group">
              {coverImage ? (
                <>
                  <img src={coverImage} className="w-full h-full object-cover" />
                  <div className="absolute inset-0 bg-slate-900/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                    <p className="text-white text-xs font-bold bg-white/20 px-3 py-1 rounded-full backdrop-blur-sm">Change Image</p>
                  </div>
                </>
              ) : (
                <div className="text-center p-4">
                  <i className="fas fa-image text-slate-300 text-3xl mb-2"></i>
                  <p className="text-[10px] text-slate-400 uppercase font-black tracking-widest">Select Thumbnail</p>
                </div>
              )}
              <input type="file" accept="image/*" onChange={handleCoverUpload} className="absolute inset-0 opacity-0 cursor-pointer" />
            </div>
          </div>

          <div className="md:col-span-2 space-y-5">
            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-400 uppercase tracking-widest">Project Name</label>
              <input 
                required
                className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none transition-all font-semibold" 
                value={name}
                onChange={e => setName(e.target.value)}
                placeholder="e.g. AI Content Platform"
              />
            </div>
            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-400 uppercase tracking-widest">Tech Stack</label>
              <input 
                required
                className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none transition-all" 
                value={techStack}
                onChange={e => setTechStack(e.target.value)}
                placeholder="React, TypeScript, Node.js, Tailwind"
              />
            </div>
          </div>
        </div>

        <div className="space-y-2">
          <label className="text-xs font-bold text-slate-400 uppercase tracking-widest">Description</label>
          <textarea 
            required
            rows={4}
            className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-2 focus:ring-indigo-500 outline-none transition-all" 
            value={description}
            onChange={e => setDescription(e.target.value)}
            placeholder="What problems does this project solve? What was the inspiration?"
          />
        </div>

        <div className="space-y-6 pt-4 border-t border-slate-100">
          <div className="flex justify-between items-center">
            <h3 className="text-lg font-bold text-slate-800">Visual Walkthrough</h3>
            <Button type="button" variant="secondary" onClick={addSection} className="text-xs">
              <i className="fas fa-plus"></i> Add Section
            </Button>
          </div>
          
          <div className="space-y-6">
            {sections.map(section => (
              <div key={section.id} className="p-6 bg-slate-50 rounded-2xl border border-slate-200 flex flex-col md:flex-row gap-6 relative group">
                <button type="button" onClick={() => removeSection(section.id)} className="absolute -top-2 -right-2 w-8 h-8 bg-white border border-slate-200 text-red-500 rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity shadow-sm z-10">
                  <i className="fas fa-trash-alt text-xs"></i>
                </button>
                <div className="flex-1 space-y-4">
                  <input 
                    placeholder="Section Title (e.g. Database Architecture)"
                    className="w-full px-4 py-2 bg-white border border-slate-200 rounded-lg outline-none font-bold text-slate-800"
                    value={section.title}
                    onChange={e => updateSection(section.id, { title: e.target.value })}
                  />
                  <textarea 
                    placeholder="Provide context for this visual..."
                    className="w-full px-4 py-2 bg-white border border-slate-200 rounded-lg outline-none text-sm"
                    rows={2}
                    value={section.description}
                    onChange={e => updateSection(section.id, { description: e.target.value })}
                  />
                </div>
                <div className="w-full md:w-48 aspect-video md:aspect-square bg-white border border-slate-200 rounded-xl overflow-hidden flex-shrink-0 relative">
                  {section.screenshot ? (
                    <img src={section.screenshot} className="w-full h-full object-cover" />
                  ) : (
                    <div className="w-full h-full flex flex-col items-center justify-center text-slate-300">
                      <i className="fas fa-camera text-2xl mb-1"></i>
                      <span className="text-[10px] font-bold uppercase">Screenshot</span>
                    </div>
                  )}
                  <input type="file" accept="image/*" onChange={e => handleSectionImage(e, section.id)} className="absolute inset-0 opacity-0 cursor-pointer" />
                </div>
              </div>
            ))}
            {sections.length === 0 && (
              <div className="text-center py-10 bg-slate-50 border border-dashed border-slate-300 rounded-2xl">
                <p className="text-slate-400 text-sm">No visual sections added yet.</p>
              </div>
            )}
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 pt-4 border-t border-slate-100">
          <div className="space-y-4">
            <h3 className="text-lg font-bold text-slate-800">Files & Assets</h3>
            <div className="p-6 border-2 border-dashed border-slate-200 rounded-3xl bg-slate-50/50 hover:bg-slate-50 transition-colors">
              <label className="flex flex-col items-center gap-3 cursor-pointer">
                <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center shadow-sm text-slate-400">
                  <i className="fas fa-file-upload"></i>
                </div>
                <span className="text-xs font-bold text-slate-500 uppercase tracking-widest">Upload Individual Files</span>
                <input type="file" multiple onChange={e => handleFileUpload(e)} className="hidden" />
              </label>
              <div className="mt-6 space-y-2">
                {files.map(f => (
                  <div key={f.id} className="text-xs flex justify-between items-center bg-white p-3 rounded-xl border border-slate-200 group">
                    <div className="flex items-center gap-2 overflow-hidden">
                      <i className="fas fa-file text-indigo-400"></i>
                      <span className="truncate font-medium">{f.name}</span>
                    </div>
                    <button type="button" onClick={() => setFiles(prev => prev.filter(file => file.id !== f.id))} className="text-slate-300 hover:text-red-500 p-1">
                      <i className="fas fa-times"></i>
                    </button>
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div className="space-y-4">
            <h3 className="text-lg font-bold text-slate-800">Project Zip</h3>
            <div className="p-6 border-2 border-dashed border-indigo-100 rounded-3xl bg-indigo-50/20 hover:bg-indigo-50/40 transition-colors">
              <label className="flex flex-col items-center gap-3 cursor-pointer">
                <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center shadow-sm text-indigo-500">
                  <i className="fas fa-archive"></i>
                </div>
                <span className="text-xs font-bold text-indigo-600 uppercase tracking-widest">Attach Source Code (.zip)</span>
                <input type="file" accept=".zip,.rar,.7z" onChange={e => handleFileUpload(e, true)} className="hidden" />
              </label>
              {zipFile && (
                <div className="mt-6 p-4 bg-white rounded-2xl border border-indigo-200 flex justify-between items-center group">
                  <div className="flex items-center gap-3 overflow-hidden">
                    <div className="w-10 h-10 bg-indigo-600 rounded-lg flex items-center justify-center text-white">
                      <i className="fas fa-file-archive"></i>
                    </div>
                    <div className="overflow-hidden">
                      <p className="font-bold text-slate-800 text-sm truncate">{zipFile.name}</p>
                      <p className="text-[10px] text-slate-400">{(zipFile.size / (1024 * 1024)).toFixed(2)} MB</p>
                    </div>
                  </div>
                  <button type="button" onClick={() => setZipFile(null)} className="text-slate-300 hover:text-red-500 p-1">
                    <i className="fas fa-trash-alt"></i>
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      <div className="flex justify-end gap-4">
        <Button variant="secondary" type="button" onClick={onCancel}>Cancel</Button>
        <Button variant="primary" type="submit" isLoading={isSubmitting} className="px-10">Publish Project</Button>
      </div>
    </form>
  );
};

export default UploadForm;
