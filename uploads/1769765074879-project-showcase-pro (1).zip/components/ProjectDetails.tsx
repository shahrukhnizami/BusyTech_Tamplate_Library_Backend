
import React from 'react';
import { Project } from '../types';
import Button from './Button';

interface ProjectDetailsProps {
  project: Project;
  onBack: () => void;
}

const ProjectDetails: React.FC<ProjectDetailsProps> = ({ project, onBack }) => {
  const downloadFile = (data: string, name: string) => {
    const link = document.createElement('a');
    link.href = data;
    link.download = name;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="max-w-5xl mx-auto space-y-12 pb-24 animate-in fade-in duration-700">
      <div className="flex items-center">
        <Button variant="ghost" onClick={onBack} className="text-slate-500">
          <i className="fas fa-arrow-left"></i> Back to Dashboard
        </Button>
      </div>

      <div className="bg-white rounded-[2.5rem] overflow-hidden shadow-2xl shadow-slate-200/60 border border-slate-100">
        {project.coverImage && (
          <div className="w-full aspect-[21/9] bg-slate-900 relative overflow-hidden">
            <img src={project.coverImage} className="w-full h-full object-cover opacity-80" alt={project.name} />
            <div className="absolute inset-0 bg-gradient-to-t from-slate-900 to-transparent"></div>
            <div className="absolute bottom-10 left-10 text-white">
              <div className="flex items-center gap-2 mb-3">
                <span className="px-3 py-1 bg-indigo-600 rounded-full text-[10px] font-black uppercase tracking-tighter shadow-lg">Featured Project</span>
              </div>
              <h1 className="text-6xl font-black tracking-tight">{project.name}</h1>
            </div>
          </div>
        )}

        <div className="p-10 md:p-16">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-16">
            <div className="lg:col-span-2 space-y-12">
              <div className="space-y-6">
                <div className="flex flex-wrap gap-2">
                  {project.techStack.map(tag => (
                    <span key={tag} className="px-4 py-1.5 bg-slate-100 text-slate-700 rounded-xl text-sm font-bold border border-slate-200">
                      {tag}
                    </span>
                  ))}
                </div>
                <p className="text-xl text-slate-600 leading-relaxed font-medium">
                  {project.description}
                </p>
              </div>

              {project.aiAnalysis && (
                <div className="p-8 bg-gradient-to-br from-indigo-600 to-indigo-800 rounded-[2rem] text-white relative overflow-hidden shadow-xl shadow-indigo-200">
                  <div className="absolute top-0 right-0 p-4 opacity-10">
                    <i className="fas fa-sparkles text-8xl"></i>
                  </div>
                  <h3 className="text-lg font-black uppercase tracking-widest mb-4 flex items-center gap-2">
                    <i className="fas fa-robot"></i> Architect's Note
                  </h3>
                  <p className="text-indigo-50/90 text-lg leading-relaxed italic">
                    "{project.aiAnalysis}"
                  </p>
                </div>
              )}

              <div className="space-y-10">
                <h3 className="text-3xl font-black text-slate-900 tracking-tight">Project Visuals</h3>
                <div className="space-y-16">
                  {project.sections.map((section, idx) => (
                    <div key={section.id} className={`flex flex-col ${idx % 2 === 0 ? '' : 'lg:flex-row-reverse'} gap-10 group`}>
                      <div className="flex-1 space-y-4">
                        <div className="w-12 h-1 bg-indigo-600 rounded-full group-hover:w-20 transition-all duration-500"></div>
                        <h4 className="text-2xl font-black text-slate-800">{section.title}</h4>
                        <p className="text-slate-500 leading-relaxed">{section.description}</p>
                      </div>
                      <div className="lg:w-1/2 aspect-video bg-slate-100 rounded-3xl overflow-hidden shadow-lg border border-slate-200 group-hover:scale-[1.02] transition-transform duration-500">
                        <img src={section.screenshot} alt={section.title} className="w-full h-full object-cover" />
                      </div>
                    </div>
                  ))}
                  {project.sections.length === 0 && (
                    <div className="py-20 text-center border-2 border-dashed border-slate-200 rounded-[2rem]">
                      <p className="text-slate-400 font-medium">No visuals attached to this story.</p>
                    </div>
                  )}
                </div>
              </div>
            </div>

            <div className="space-y-10">
              <div className="p-8 bg-slate-50 rounded-[2rem] border border-slate-200 space-y-8 sticky top-28">
                <div className="space-y-6">
                  <h4 className="text-xs font-black text-slate-400 uppercase tracking-widest">Distribution</h4>
                  
                  {project.zipFile && (
                    <div 
                      onClick={() => downloadFile(project.zipFile!.data, project.zipFile!.name)}
                      className="group cursor-pointer p-6 bg-slate-900 rounded-2xl text-white hover:bg-slate-800 transition-all shadow-lg shadow-slate-200 active:scale-95"
                    >
                      <div className="flex justify-between items-center mb-4">
                        <div className="w-12 h-12 bg-white/10 rounded-xl flex items-center justify-center text-xl">
                          <i className="fas fa-file-archive"></i>
                        </div>
                        <i className="fas fa-download text-slate-500 group-hover:text-white transition-colors"></i>
                      </div>
                      <p className="text-xs text-indigo-400 font-bold uppercase tracking-widest mb-1">Source Repository</p>
                      <h5 className="font-black text-lg truncate">{project.zipFile.name}</h5>
                    </div>
                  )}

                  <div className="space-y-4">
                    <p className="text-xs font-black text-slate-400 uppercase tracking-widest">Asset Manifest</p>
                    <div className="space-y-2">
                      {project.files.map(file => (
                        <div key={file.id} className="flex items-center justify-between p-4 bg-white border border-slate-200 rounded-2xl hover:border-indigo-300 transition-colors group">
                          <div className="flex items-center gap-3 overflow-hidden">
                            <i className="fas fa-file-code text-indigo-400"></i>
                            <div className="overflow-hidden">
                              <p className="text-sm font-bold text-slate-800 truncate">{file.name}</p>
                              <p className="text-[10px] text-slate-400 uppercase">{(file.size / 1024).toFixed(1)} KB</p>
                            </div>
                          </div>
                          <button 
                            onClick={() => downloadFile(file.data, file.name)}
                            className="w-8 h-8 flex items-center justify-center text-slate-300 hover:text-indigo-600 transition-colors"
                          >
                            <i className="fas fa-download"></i>
                          </button>
                        </div>
                      ))}
                      {project.files.length === 0 && !project.zipFile && (
                        <p className="text-slate-400 text-xs italic text-center py-4">No distributables provided.</p>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProjectDetails;
