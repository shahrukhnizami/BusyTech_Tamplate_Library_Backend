
import React from 'react';
import { Project } from '../types';
import Button from './Button';

interface ProjectCardProps {
  project: Project;
  onView: (id: string) => void;
  onDelete: (id: string) => void;
}

const ProjectCard: React.FC<ProjectCardProps> = ({ project, onView, onDelete }) => {
  const coverImage = project.coverImage || project.sections[0]?.screenshot || "https://picsum.photos/400/300";

  return (
    <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden hover:shadow-md transition-shadow">
      <div className="h-48 overflow-hidden relative group">
        <img src={coverImage} alt={project.name} className="w-full h-full object-cover" />
        <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
          <Button variant="primary" onClick={() => onView(project.id)}>
            <i className="fas fa-eye"></i> View Project
          </Button>
        </div>
      </div>
      <div className="p-5">
        <div className="flex justify-between items-start mb-2">
          <h3 className="text-xl font-bold text-slate-800 line-clamp-1">{project.name}</h3>
          <span className="text-xs bg-indigo-50 text-indigo-600 px-2 py-1 rounded-full font-semibold">
            {project.techStack.length} Tags
          </span>
        </div>
        <p className="text-slate-600 text-sm line-clamp-2 mb-4 h-10">
          {project.description}
        </p>
        <div className="flex flex-wrap gap-1 mb-4">
          {project.techStack.slice(0, 3).map((tag, i) => (
            <span key={i} className="text-[10px] uppercase tracking-wider bg-slate-100 px-1.5 py-0.5 rounded text-slate-500">
              {tag}
            </span>
          ))}
          {project.techStack.length > 3 && (
            <span className="text-[10px] text-slate-400">+{project.techStack.length - 3} more</span>
          )}
        </div>
        <div className="flex items-center justify-end text-xs text-slate-400">
          <button 
            onClick={() => onDelete(project.id)}
            className="text-red-400 hover:text-red-600 transition-colors"
          >
            <i className="fas fa-trash"></i>
          </button>
        </div>
      </div>
    </div>
  );
};

export default ProjectCard;
