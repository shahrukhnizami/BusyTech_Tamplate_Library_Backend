
export interface ProjectSection {
  id: string;
  title: string;
  description: string;
  screenshot: string; // base64 string
}

export interface ProjectFile {
  id: string;
  name: string;
  data: string; // base64 string
  type: string;
  size: number;
}

export interface Project {
  id: string;
  name: string;
  description: string;
  techStack: string[];
  startDate: string;
  endDate: string;
  coverImage?: string; // primary display image
  sections: ProjectSection[];
  files: ProjectFile[];
  zipFile: ProjectFile | null;
  aiAnalysis?: string;
  createdAt: number;
}
